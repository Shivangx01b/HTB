require 'winrm'





# Author: Alamot

conn = WinRM::Connection.new(



  endpoint: 'http://127.0.0.1:5985/wsman',



  user: 'simple',



  password: 'ZonoProprioZomaro:-(',



  :no_ssl_peer_verification => true



)







command=""







conn.shell(:powershell) do |shell|



    until command == "exit\n" do



        print "PS > "



        command = gets



        output = shell.run(command) do |stdout, stderr|



            STDOUT.print stdout



            STDERR.print stderr



        end



    end



    puts "Exiting with code #{output.exitcode}"



end
